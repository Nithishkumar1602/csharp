﻿using System;
using System.Data.SqlClient;
class exe
{
    public static void Main(string[] args)
    {
        int a, flag = 0;
        string connec = @"Data Source =(localdb)\mssqllocaldb;Initial Catalog =sarvash;Integrated Security=True";
        SqlConnection con = new SqlConnection(connec);
        con.Open();
        Console.WriteLine("1.Select\n2.Insert\n3.Update\n4.Delete\n5.Exit");
        while (true)
        {
            Console.WriteLine("Enter your choice :");
            a = Convert.ToInt32(Console.ReadLine());
            switch (a)
            {
                case 1:
                    string querystring = "select * from Department";
                    SqlCommand cmd1 = new SqlCommand(querystring, con);
                    SqlDataReader reader = cmd1.ExecuteReader();
                    while (reader.Read())
                    {
                        Console.WriteLine(reader[0].ToString() + " " + reader[1].ToString());
                    }
                    reader.Close();
                    break;
                case 2:
                    Console.WriteLine("Enter the Department ID :");
                    int id = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Department Name :");
                    string name = Console.ReadLine();
                    string inser = "insert into Department(DepID,DeptName) values('" + id + "','" + name + "')";
                    SqlCommand cmd2 = new SqlCommand(inser, con);
                    cmd2.ExecuteNonQuery();
                    Console.WriteLine("Inserted successfully");
                    break;

                case 3:
                    Console.WriteLine("Enter the Department ID :");
                    int id1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter the Department Name :");
                    string name1 = Console.ReadLine();
                    string updat = "update Department set DeptName='" + name1 + "' where DepID='" + id1 + "'";
                    SqlCommand cmd3 = new SqlCommand(updat, con);
                    cmd3.ExecuteNonQuery();
                    Console.WriteLine("Updated sucessfully");
                    break;

                case 4:
                    Console.WriteLine("Enter your ID :");
                    int id3 = Convert.ToInt32(Console.ReadLine());
                    string del = "delete from Department where DepID='" + id3 + "'";
                    SqlCommand cmd4 = new SqlCommand(del, con);
                    cmd4.ExecuteNonQuery();
                    Console.WriteLine("Deleted successfully");
                    break;

                case 5:
                    flag = 1;
                    break;
            }
            if (flag == 1)
            {
                con.Close();
                break;
            }
        }
    }
}