﻿using System;

using System.Data;

using System.Data.SqlClient;

namespace exer8

{

    internal class Program

    {

        static void Main(string[] args)

        {

            int ch, flag = 0;

            string query;

            Console.WriteLine("1Select\n2-Insert\n3-Update\n4-Delete\n5-Exit.");

            string constr = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=sarvash;Integrated Security=True";

            SqlConnection conn = new SqlConnection(constr);

            conn.Open();

            query = "select * from Department1;";

            SqlDataAdapter da = new SqlDataAdapter(query, conn);

            DataSet ds = new DataSet();

            da.Fill(ds, "Department1");

            while (true)

            {

                Console.Write("Enter your choise(1-5):");

                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {

                    case 1:

                        Console.WriteLine("Id Dept_name");

                        foreach (DataRow ddr in ds.Tables["Department1"].Rows)
                        {

                            Console.WriteLine(ddr["id"].ToString() + " " + ddr["Dept_name"].ToString());

                        }

                        break;

                    case 2:

                        Console.Write("Enter the dept id :");

                        int id = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the dept name :");

                        string name = Console.ReadLine();

                        DataRow dr = ds.Tables["Department1"].NewRow();

                        dr["id"] = id;

                        dr["Dept_name"] = name;

                        ds.Tables["Department1"].Rows.Add(dr);

                        Console.WriteLine("inserted successfully..");

                        break;

                    case 3:

                        Console.Write("Enter the dept id :");

                        int id1 = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Enter the new dept name :");

                        string name1 = Console.ReadLine();

                        foreach (DataRow ddr in ds.Tables["Department1"].Rows)
                        {

                            int cho = Convert.ToInt32(ddr["id"].ToString());

                            if (cho == id1)
                            {

                                ddr["Dept_name"] = name1;

                                break;

                            }

                        }

                        Console.WriteLine("updated successfully..");

                        break;

                    case 4:

                        Console.Write("Enter the dept id :");

                        int id2 = Convert.ToInt32(Console.ReadLine());

                        foreach (DataRow ddr in ds.Tables["Department1"].Rows)

                        {

                            int cho = Convert.ToInt32(ddr["id"].ToString());

                            if (cho == id2)
                            {

                                ddr.Delete();

                                break;

                            }

                        }

                        Console.WriteLine("deleted successfully..");

                        break;

                    case 5:

                        SqlCommandBuilder build = new SqlCommandBuilder(da);

                        da.Update(ds, "Department1");

                        flag = 1;

                        break;

                }

                if (flag == 1) { break; }

            }

        }

    }

}